
<img src="<?php echo e(asset('binary_traders_forum_logo.png')); ?>" width="100">

<h3>Hello <?php echo e($name); ?></h3>

<p>
    <?php echo e($status); ?>

</p>

<p align="center">Need more information?<br>
    Please contact <strong>info@binarytradersforum.com</strong>.</p>
<?php /**PATH C:\wamp64\www\digital_metrics_invest\resources\views/emails/verify-user.blade.php ENDPATH**/ ?>
