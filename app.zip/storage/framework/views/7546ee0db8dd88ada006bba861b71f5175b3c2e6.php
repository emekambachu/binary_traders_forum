<?php $__env->startSection('title'); ?>
    Investment Packages
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
    <section class="page-title-section">
        <div class="container">
            <div class="row">
                <div class="col-xl-12 text-center">
                    <h2 class="text-uppercase text-white mrb-10">Investment Plans</h2>
                    <ul class="mb-0 justify-content-center">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>" class="text-white">Home</a></li>
                        <li class="breadcrumb-item" style="color: #3d9bef;">Investment plans</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <section class="price-section pdt-125 pdb-100">
        <div class="container">
            <div class="row">

                <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="price-table mrb-30 text-center">
                        <div class="table-header">
                            <h6 class="price"><span class="price-currency">$</span><?php echo e(number_format($package->min)); ?> - $<?php echo e(number_format($package->max)); ?></h6>
                            <h2 class="pricing-plan-name"><?php echo e($package->name); ?></h2>
                        </div>
                        <div class="table-content">
                            <ul class="list-items">
                                <li><i class="fa fa-check mrr-10 text-green"></i><?php echo e($package->referral_bonus); ?>% Referral Bonus</li>
                                <li><i class="fa fa-check mrr-10 text-green"></i><?php echo e($package->monthly_profit); ?>% Monthly Profit</li>
                                <li><i class="fa fa-check mrr-10 text-green"></i><?php echo e($package->days_turnover); ?> Days Turnover</li>
                                <li><i class="fa fa-check mrr-10 text-green"></i><?php echo e($package->expert_advice); ?></li>
                                <li><i class="fa fa-check mrr-10 text-green"></i><?php echo e($package->deposit_bonus); ?>% Deposit Bonus</li>
                            </ul>
                        </div>
                        <div class="table-footer">
                            <a href="<?php echo e(route('register')); ?>" class="cs-btn-one btn-primary-color">Sign up</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </section>




































































































































































































































<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\binary_traders_forum\resources\views/investment-packages.blade.php ENDPATH**/ ?>