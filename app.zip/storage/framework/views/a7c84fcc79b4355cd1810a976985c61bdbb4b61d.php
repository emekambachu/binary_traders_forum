<?php $__env->startSection('title'); ?>
    Sign Up
<?php $__env->stopSection(); ?>

<?php $__env->startSection('top-assets'); ?>
    <script src="<?php echo e(asset('js/countries.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
    <section class="inner-banner has-dot-pattern">
        <div class="container">
            <h2>Create your account and start earning</h2>
            <span class="decor-line"></span>
            <ul class="list-inline bread-cumb">
                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li><span>Sign up</span></li>
            </ul><!-- /.list-inline -->
        </div><!-- /.container -->
    </section>

    <section class="sec-pad contact-page">
        <div class="container">
            <div class="col-md-8">

                <?php echo $__env->make('includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <form method="POST" action="<?php echo e(route('register')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                        <div class="row" style="margin-bottom: 10px;">
                            <div class="col-md-6">
                                <div class="form-grp">
                                    <label>Full Name</label>
                                    <input class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="name" value="<?php echo e(old('name')); ?>" placeholder="Your Name *" required>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div><!-- /.form-grp -->
                            </div><!-- /.col-md-6 -->
                            <div class="col-md-6">
                                <div class="form-grp">
                                    <label>Email</label>
                                    <input class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email Address *" required>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div><!-- /.form-grp -->
                            </div><!-- /.col-md-6 -->
                        </div>

                    <div class="row" style="margin-bottom: 10px;">
                            <div class="col-md-6">
                                <div class="form-grp">
                                    <label>Mobile Number</label>
                                    <input class="form-control <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="tel" name="mobile"
                                           value="<?php echo e(old('mobile')); ?>" placeholder="Mobile Number">
                                    <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div><!-- /.form-grp -->
                            </div><!-- /.col-md-6 -->
                            <div class="col-md-6">
                                <div class="form-grp">
                                    <label>ID Card</label>
                                    <input class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" name="image" required>
                                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div><!-- /.form-grp -->
                            </div><!-- /.col-md-6 -->
                        </div>

                    <div class="row" style="margin-bottom: 10px;">
                            <div class="col-md-6">
                                <div class="form-grp">
                                    <label>Password</label>
                                    <input class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password" name="password" placeholder="Password" autocomplete="new-password" required>
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div><!-- /.form-grp -->
                            </div><!-- /.col-md-6 -->
                            <div class="col-md-6">
                                <div class="form-grp">
                                    <label>Confirm Password</label>
                                    <input class="form-control" type="password" name="password_confirmation"
                                           autocomplete="new-password" placeholder="Confirm Password" required>
                                </div><!-- /.form-grp -->
                            </div><!-- /.col-md-6 -->
                        </div>

                    <div class="row" style="margin-bottom: 10px;">
                            <div class="col-md-6">
                                <div class="form-grp">
                                    <label>Country</label>
                                    <select class="form-control" id="country" name="country" required></select>
                                    <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div><!-- /.form-grp -->
                            </div><!-- /.col-md-6 -->
                            <div class="col-md-6">
                                <div class="form-grp">
                                    <label>State</label>
                                    <select class="form-control" id="state" name="state"></select>
                                    <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div><!-- /.form-grp -->
                            </div><!-- /.col-md-6 -->

                            <script language="javascript">
                                populateCountries("country", "state");
                                populateCountries("country2");
                            </script>
                        </div>

                    <div class="row" style="margin-bottom: 10px;">
                            <div class="col-md-12">
                                <div class="form-grp">
                                    <label>Address</label>
                                    <input class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                                           name="address" placeholder="Address" value="<?php echo e(old('address')); ?>">
                                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div><!-- /.form-grp -->
                            </div><!-- /.col-md-12 -->
                        </div>
                        <button type="submit" class="thm-btn">Sign up</button>
                </form>
            </div><!-- /.col-md-8 -->

            <div class="col-md-4">
                <div class="sec-title">
                    <h2>Sign up</h2>
                    <span class="decor-line">
					<span class="decor-line-inner"></span>
				</span>
                </div>
                <div class="contact-info-box">
                    <ul class="info-items">
                        <li>
                            <div class="icon-box">
                                <div class="inner-box">
                                    <i class="fa fa-envelope"></i>
                                </div><!-- /.inner-box -->
                            </div><!-- /.icon-box -->
                            <div class="text-box">
                                <h3>Ask Anything Here :</h3>
                                <p>info@binarytradersforum.com</p>
                            </div><!-- /.text-box -->
                        </li>
                    </ul><!-- /.info-items -->
                </div><!-- /.contact-info-box -->
            </div><!-- /.col-md-8 -->
        </div><!-- /.container -->
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\digital_metrics_invest\resources\views/auth/register.blade.php ENDPATH**/ ?>
