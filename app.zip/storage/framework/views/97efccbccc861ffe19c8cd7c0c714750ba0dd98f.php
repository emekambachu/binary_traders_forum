
<img src="<?php echo e(asset('binary_traders_forum_logo.png')); ?>" width="100">

<h3>Dear <?php echo e($name); ?>,</h3>

<p>
    Your Investment was successful.<br>
    Once your payment has been approved, your waller would be funded.<br><br>
</p>

<p><strong>Below are your payment details:</strong></p>
<ul>
    <li>Investment ID: <?php echo e($investment_id); ?></li>
    <li>Amount: <?php echo e($amount); ?></li>
    <li>Investment Package: <?php echo e($investment_package); ?></li>
    <li>Status: <?php echo e($status ? 'Approved' : 'Unapproved'); ?></li>
</ul>

<p align="center">Need more information?<br>
    Please contact <strong>info@binarytradersforum.com</strong>.</p>


<?php /**PATH C:\wamp64\www\digital_metrics_invest\resources\views/emails/add-new-investment.blade.php ENDPATH**/ ?>
