<?php $__env->startSection('title'); ?>
Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
    <section class="rev_slider_wrapper">
        <div class="rev_slider slider1" id="slider1"  data-version="5.0" data-height="900">
            <ul>
                <li data-transition="random">
                    <img src="<?php echo e(asset('img/resources/banner-1.jpg')); ?>"  alt="" width="1920" height="900" data-bgposition="top center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="1" >

                    <div class="tp-caption tp-resizeme banner-caption-h1 text-center ttu"
                         data-x="center" data-hoffset="0"
                         data-y="top" data-voffset="340"
                         data-transform_idle="o:1;"
                         data-transform_in="x:[175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0.01;s:3000;e:Power3.easeOut;"
                         data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
                         data-mask_in="x:[-100%];y:0;s:inherit;e:inherit;"
                         data-splitin="none"
                         data-splitout="none"
                         data-responsive_offset="on"
                         data-start="1000">
                        Digital Metrics <br />Investment
                    </div>

                    <div class="tp-caption tp-resizeme banner-caption-p text-center"
                         data-x="center" data-hoffset="0"
                         data-y="top" data-voffset="585"
                         data-transform_idle="o:1;"
                         data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;"
                         data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
                         data-splitin="none"
                         data-splitout="none"
                         data-responsive_offset="on"
                         data-start="1500">
                        Invest in digital and, <br />Crypto Currencies.
                    </div>

                    <div class="tp-caption tp-resizeme"
                         data-x="center" data-hoffset="0"
                         data-y="top" data-voffset="680"
                         data-transform_idle="o:1;"
                         data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;"
                         data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
                         data-splitin="none"
                         data-splitout="none"
                         data-responsive_offset="on"
                         data-start="2000">
                        <a href="#" class="thm-btn">Know About Us</a>
                    </div>

                </li>
                <li data-transition="random">
                    <img src="<?php echo e(asset('img/resources/banner-2.jpg')); ?>"  alt="" width="1920" height="900" data-bgposition="top center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="1" >
                    <div class="tp-caption tp-resizeme banner-caption-h2"
                         data-x="left" data-hoffset="0"
                         data-y="top" data-voffset="340"
                         data-transform_idle="o:1;"
                         data-transform_in="x:[175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0.01;s:3000;e:Power3.easeOut;"
                         data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
                         data-mask_in="x:[-100%];y:0;s:inherit;e:inherit;"
                         data-splitin="none"
                         data-splitout="none"
                         data-responsive_offset="on"
                         data-start="1000">
                        <span class="ttu">Start Your Future<br />Financial Plan</span>
                    </div>

                    <div class="tp-caption tp-resizeme"
                         data-x="left" data-hoffset="0"
                         data-y="top" data-voffset="610"
                         data-transform_idle="o:1;"
                         data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;"
                         data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
                         data-splitin="none"
                         data-splitout="none"
                         data-responsive_offset="on"
                         data-start="2000">
                        <a href="#" class="thm-btn">View Services</a>
                    </div>
                </li>

            </ul>
        </div>
    </section>

    <section class="sec-pad service-box-one">
        <div class="container">
            <div class="sec-title text-center">
                <h2>Our Role</h2>
                <span class="decor-line">
                <span class="decor-line-inner"></span>
            </span>
            </div><!-- /.sec-title -->
            <div class="row">
                <div class="col-md-4 col-sm-6">
                    <div class="single-service-box-one">
                        <div class="icon-box">
                            <i class="fn-icon-safe"></i>
                        </div><!-- /.icon-box -->
                        <div class="title-box clearfix">
                            <div class="title pull-left">
                                <h3>Investing</h3>
                            </div><!-- /.title -->
                            <div class="number-box pull-right">
                                <span>01</span>
                            </div><!-- /.number-box -->
                        </div><!-- /.title-box -->
                        <p>A wide selection of investment product which include forex, crypto and stock options, to help build diversified portfolio.</p>
                    </div><!-- /.service-box-one -->
                </div><!-- /.col-md-4 -->
                <div class="col-md-4 col-sm-6">
                    <div class="single-service-box-one">
                        <div class="icon-box">
                            <i class="fn-icon-insurance-sign"></i>
                        </div><!-- /.icon-box -->
                        <div class="title-box clearfix">
                            <div class="title pull-left">
                                <h3>Trading</h3>
                            </div><!-- /.title -->
                            <div class="number-box pull-right">
                                <span>02</span>
                            </div><!-- /.number-box -->
                        </div><!-- /.title-box -->
                        <p>Powerful trading tools, resources and support.</p>
                    </div><!-- /.service-box-one -->
                </div><!-- /.col-md-4 -->
                <div class="col-md-4 col-sm-6">
                    <div class="single-service-box-one">
                        <div class="icon-box">
                            <i class="fn-icon-up-arrow"></i>
                        </div><!-- /.icon-box -->
                        <div class="title-box clearfix">
                            <div class="title pull-left">
                                <h3>Advisor Network</h3>
                            </div><!-- /.title -->
                            <div class="number-box pull-right">
                                <span>03</span>
                            </div><!-- /.number-box -->
                        </div><!-- /.title-box -->
                        <p>Specialized guidance from independent local advisor for high-net-worth investors.</p>
                    </div><!-- /.service-box-one -->
                </div><!-- /.col-md-4 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </section><!-- /.sec-pad service-box-one -->

    <section class="service-box-two sec-pad">
        <div class="container">
            <div class="sec-title text-center">
                <h2>Our Services</h2>
                <span class="decor-line">
                <span class="decor-line-inner"></span>
            </span>
            </div>
            <div class="row">

                <div class="col-md-4 col-sm-6">
                    <div class="single-service-box-two clearfix">
                        <div class="icon-box">
                            <div class="inner-box">
                                <div class="top-box">
                                    <i class="fn-icon-money-2"></i>
                                </div><!-- /.top-box -->
                                <div class="bottom-box">
                                    <i class="fn-icon-money-2"></i>
                                </div><!-- /.bottom-box -->
                            </div><!-- /.inner-box -->
                        </div><!-- /.icon-box -->
                        <div class="text-box">
                            <h3>Cryptocurrency</h3>
                            <p style="color: #797979;">Trade with a broad range of investments, such as stocks.</p>
                        </div><!-- /.text-box -->
                    </div><!-- /.single-service-box-two -->
                </div><!-- /.col-md-4 -->

                <div class="col-md-4 col-sm-6">
                    <div class="single-service-box-two clearfix">
                        <div class="icon-box">
                            <div class="inner-box">
                                <div class="top-box">
                                    <i class="fn-icon-tool-1"></i>
                                </div><!-- /.top-box -->
                                <div class="bottom-box">
                                    <i class="fn-icon-tool-1"></i>
                                </div><!-- /.bottom-box -->
                            </div><!-- /.inner-box -->
                        </div><!-- /.icon-box -->
                        <div class="text-box">
                            <h3>Forex</h3>
                            <p style="color: #797979;">Options for investing cash including certificates of deposit and the money market funds. With CDs.</p>
                        </div><!-- /.text-box -->
                    </div><!-- /.single-service-box-two -->
                </div><!-- /.col-md-4 -->

                <div class="col-md-4 col-sm-6">
                    <div class="single-service-box-two clearfix">
                        <div class="icon-box">
                            <div class="inner-box">
                                <div class="top-box">
                                    <i class="fn-icon-money"></i>
                                </div><!-- /.top-box -->
                                <div class="bottom-box">
                                    <i class="fn-icon-money"></i>
                                </div><!-- /.bottom-box -->
                            </div><!-- /.inner-box -->
                        </div><!-- /.icon-box -->
                        <div class="text-box">
                            <h3>Options Trading</h3>
                            <p style="color: #797979;">We offer the best forex and options trading services operating closely with an expert team</p>
                        </div><!-- /.text-box -->
                    </div><!-- /.single-service-box-two -->
                </div><!-- /.col-md-4 -->

                <div class="col-md-4 col-sm-6">
                    <div class="single-service-box-two clearfix">
                        <div class="icon-box">
                            <div class="inner-box">
                                <div class="top-box">
                                    <i class="fn-icon-buildings"></i>
                                </div><!-- /.top-box -->
                                <div class="bottom-box">
                                    <i class="fn-icon-buildings"></i>
                                </div><!-- /.bottom-box -->
                            </div><!-- /.inner-box -->
                        </div><!-- /.icon-box -->
                        <div class="text-box">
                            <h3>Assets Management</h3>
                            <p style="color: #797979;">We manage assets for ROI on important projects, construction, contracts, and ect.</p> </div><!-- /.text-box -->
                    </div><!-- /.single-service-box-two -->
                </div><!-- /.col-md-4 -->

                <div class="col-md-4 col-sm-6">
                    <div class="single-service-box-two clearfix">
                        <div class="icon-box">
                            <div class="inner-box">
                                <div class="top-box">
                                    <i class="fn-icon-commerce"></i>
                                </div><!-- /.top-box -->
                                <div class="bottom-box">
                                    <i class="fn-icon-commerce"></i>
                                </div><!-- /.bottom-box -->
                            </div><!-- /.inner-box -->
                        </div><!-- /.icon-box -->
                        <div class="text-box">
                            <h3>Commodities</h3>
                            <p style="color: #797979;">A commodity is a basic of good used in commerce that is interchangeable with other commodities of same.</p>
                        </div><!-- /.text-box -->
                    </div><!-- /.single-service-box-two -->
                </div><!-- /.col-md-4 -->

                <div class="col-md-4 col-sm-6">
                    <div class="single-service-box-two clearfix">
                        <div class="icon-box">
                            <div class="inner-box">
                                <div class="top-box">
                                    <i class="fn-icon-money-1"></i>
                                </div><!-- /.top-box -->
                                <div class="bottom-box">
                                    <i class="fn-icon-money-1"></i>
                                </div><!-- /.bottom-box -->
                            </div><!-- /.inner-box -->
                        </div><!-- /.icon-box -->
                        <div class="text-box">
                            <h3>Funds Management</h3>
                            <p style="color: #797979;">This offer includes the forex, crypto and options market, equity, fixed income, real estate.</p>
                        </div><!-- /.text-box -->
                    </div><!-- /.single-service-box-two -->
                </div><!-- /.col-md-4 -->

            </div><!-- /.row -->
        </div><!-- /.container -->
    </section><!-- /.service-box-two -->

    <section class="home-parallax-one has-dot-pattern sec-pad">
        <div class="container">
            <div class="row">
                <div class="col-md-5 pull-left col-sm-12 col-xs-12">
                    <h3>Your Financial Plan Is a<br />Life Plan!</h3>
                    <p style="color: #ffffff;">Our market depth and knowledge are attributed to our acquired experience on trading floors of many exchanges. With over $5.3 Trillion traded daily in the foreign exchange market and over $200 billion traded in the cryptospace, we are dedicated to giving our clients their own share of the profits regularly.</p>
                    <a href="<?php echo e(url('about')); ?>" class="thm-btn">Know More</a>
                </div><!-- /.col-md-5 -->
                <div class="pull-right col-md-5 col-sm-12 col-xs-12">
                    <!-- TradingView Widget BEGIN -->
                    <div class="tradingview-widget-container">
                        <div class="tradingview-widget-container__widget"></div>
                        <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/markets/stocks-usa/market-movers-gainers/" rel="noopener" target="_blank"><span class="blue-text">Stock Market</span></a> by TradingView</div>
                        <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-hotlists.js" async>
                            {
                                "colorTheme": "light",
                                "dateRange": "12m",
                                "exchange": "US",
                                "showChart": true,
                                "locale": "en",
                                "largeChartUrl": "",
                                "isTransparent": false,
                                "width": "400",
                                "height": "450",
                                "plotLineColorGrowing": "rgba(33, 150, 243, 1)",
                                "plotLineColorFalling": "rgba(33, 150, 243, 1)",
                                "gridLineColor": "rgba(240, 243, 250, 1)",
                                "scaleFontColor": "rgba(120, 123, 134, 1)",
                                "belowLineFillColorGrowing": "rgba(33, 150, 243, 0.12)",
                                "belowLineFillColorFalling": "rgba(33, 150, 243, 0.12)",
                                "symbolActiveColor": "rgba(33, 150, 243, 0.12)"
                            }
                        </script>
                    </div>
                    <!-- TradingView Widget END -->
                </div><!-- /.pull-right col-md-5 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </section><!-- /.home-parallax-one -->

    <section class="sec-pad about-tab-box pb0">
        <div class="container">
            <div class="sec-title">
                <h2>About Binary Traders Forum</h2>
                <span class="decor-line">
                <span class="decor-line-inner"></span>
            </span>
            </div><!-- /.sec-title -->
            <div class="row">
                <div class="col-md-3">
                    <div class="single-sidebar">
                        <div class="sidebar-links">
                            <ul role="tablist">
                                <li class="active" data-tab-name="overview">
                                    <a href="#overview" aria-controls="overview" role="tab" data-toggle="tab">Company Overview</a>
                                </li>
                                <li data-tab-name="process">
                                    <a href="#process" aria-controls="process" role="tab" data-toggle="tab">Process Management</a>
                                </li>
                                <li data-tab-name="relationshiop">
                                    <a href="#relationshiop" aria-controls="relationshiop" role="tab" data-toggle="tab">Customer Relationship</a>
                                </li>
                                <li data-tab-name="management">
                                    <a href="#management" aria-controls="management" role="tab" data-toggle="tab">Management</a>
                                </li>
                            </ul>
                        </div><!-- /.sidebar-links -->
                    </div><!-- /.single-sidebar -->
                </div><!-- /.col-md-3 -->
                <div class="col-md-9">
                    <div class="tab-content">
                        <div class="tab-pane fade in active" id="overview">
                            <div class="row">
                                <div class="col-md-7">
                                    <div class="about-tab-text-box">
                                        <div class="qouted-text">
                                            <p>
                                                <span class="qoute-top">“</span>
                                                We are a leading investment provider to financial market professionals
                                                <span class="qoute-bottom">”</span>
                                            </p>
                                        </div><!-- /.qouted-text -->
                                        <br />
                                        <br />
                                        <p>Binary Traders Forum is a fund management company aimed at making maximum profits for our clients. We know the games brokers play. Being fund managers, we have created this framework of impeccable standards with complete transparency and the latest in trading technology.</p>
                                        <p>we are offering everyone interested to use a modern and profitable instrument of online investing. Every client of our company can invest our minimum amount in order to receive regular passive income and this is very easy to do.</p>
                                        <img src="<?php echo e(asset('img/texture/sign.png')); ?>" alt="Awesome Image"/>
                                    </div><!-- /.about-tab-text-box -->
                                </div><!-- /.col-md-7 -->
                                <div class="col-md-5">
                                    <div class="about-img-box">
                                        <img src="<?php echo e(asset('img/resources/man-1.png')); ?>" alt="Awesome Image" class="wow fadeIn" data-wow-duration="2s" data-wow-delay="0s" data-wow-offset="0"/>
                                    </div><!-- /.about-img-box -->
                                </div><!-- /.col-md-5 -->
                            </div><!-- /.row -->
                        </div><!-- /.tab-pane fade in active -->
                        <div class="tab-pane fade" id="process">
                            <div class="row">
                                <div class="col-md-7">
                                    <div class="about-tab-text-box">
                                        <div class="qouted-text">
                                            <p>
                                                <span class="qoute-top">“</span>
                                                We provide full and specific solution for every client.
                                                <span class="qoute-bottom">”</span>
                                            </p>
                                        </div><!-- /.qouted-text -->
                                        <br />
                                        <br />
                                        <p>Binary Traders Forum is one of the world's best company in a financial sectors We 100%  providing what our customers expects from us.</p>
                                        <p>The Great denouncings pleasures and praisings pains was born and  will give you a complete seds accounts off the systems and expound the actually  teachings the great seds ut explorers the masterd  teachings great explorer of human happiness.</p>
                                        <img src="<?php echo e(asset('img/texture/sign.png')); ?>" alt="Awesome Image"/>
                                    </div><!-- /.about-tab-text-box -->
                                </div><!-- /.col-md-7 -->
                                <div class="col-md-5">
                                    <div class="about-img-box">
                                        <img src="<?php echo e(asset('img/resources/man-1.png')); ?>" alt="Awesome Image"/>
                                    </div><!-- /.about-img-box -->
                                </div><!-- /.col-md-5 -->
                            </div><!-- /.row -->
                        </div><!-- /.tab-pane fade -->
                        <div class="tab-pane fade" id="relationshiop">
                            <div class="row">
                                <div class="col-md-7">
                                    <div class="about-tab-text-box">
                                        <div class="qouted-text">
                                            <p>
                                                <span class="qoute-top">“</span>
                                                We provide full and specific solution for every client.
                                                <span class="qoute-bottom">”</span>
                                            </p>
                                        </div><!-- /.qouted-text -->
                                        <br />
                                        <br />
                                        <p>Binary Traders Forum is one of the world's best company in a financial sectors We 100%  providing what our customers expects from us.</p>
                                        <p>The Great denouncings pleasures and praisings pains was born and  will give you a complete seds accounts off the systems and expound the actually  teachings the great seds ut explorers the masterd  teachings great explorer of human happiness.</p>
                                        <img src="<?php echo e(asset('img/texture/sign.png')); ?>" alt="Awesome Image"/>
                                    </div><!-- /.about-tab-text-box -->
                                </div><!-- /.col-md-7 -->
                                <div class="col-md-5">
                                    <div class="about-img-box">
                                        <img src="<?php echo e(asset('img/resources/man-1.png')); ?>" alt="Awesome Image"/>
                                    </div><!-- /.about-img-box -->
                                </div><!-- /.col-md-5 -->
                            </div><!-- /.row -->
                        </div><!-- /.tab-pane fade -->
                        <div class="tab-pane fade" id="management">
                            <div class="row">
                                <div class="col-md-7">
                                    <div class="about-tab-text-box">
                                        <div class="qouted-text">
                                            <p>
                                                <span class="qoute-top">“</span>
                                                We provide full and specific solution for every client.
                                                <span class="qoute-bottom">”</span>
                                            </p>
                                        </div><!-- /.qouted-text -->
                                        <br />
                                        <br />
                                        <p>Binary Traders Forum is one of the world's best company in a financial sectors We 100%  providing what our customers expects from us.</p>
                                        <p>The Great denouncings pleasures and praisings pains was born and  will give you a complete seds accounts off the systems and expound the actually  teachings the great seds ut explorers the masterd  teachings great explorer of human happiness.</p>
                                        <img src="<?php echo e(asset('img/texture/sign.png')); ?>" alt="Awesome Image"/>
                                    </div><!-- /.about-tab-text-box -->
                                </div><!-- /.col-md-7 -->
                                <div class="col-md-5">
                                    <div class="about-img-box">
                                        <img src="<?php echo e(asset('img/resources/man-1.png')); ?>" alt="Awesome Image"/>
                                    </div><!-- /.about-img-box -->
                                </div><!-- /.col-md-5 -->
                            </div><!-- /.row -->
                        </div><!-- /.tab-pane fade -->

                        <div class="tab-pane fade" id="development">
                            <div class="row">
                                <div class="col-md-7">
                                    <div class="about-tab-text-box">
                                        <div class="qouted-text">
                                            <p>
                                                <span class="qoute-top">“</span>
                                                We provide full and specific solution for every client.
                                                <span class="qoute-bottom">”</span>
                                            </p>
                                        </div><!-- /.qouted-text -->
                                        <br />
                                        <br />
                                        <p>Binary Traders Forum is one of the world's best company in a financial sectors We 100%  providing what our customers expects from us.</p>
                                        <p>The Great denouncings pleasures and praisings pains was born and  will give you a complete seds accounts off the systems and expound the actually  teachings the great seds ut explorers the masterd  teachings great explorer of human happiness.</p>
                                        <img src="<?php echo e(asset('img/texture/sign.png')); ?>" alt="Awesome Image"/>
                                    </div><!-- /.about-tab-text-box -->
                                </div><!-- /.col-md-7 -->
                                <div class="col-md-5">
                                    <div class="about-img-box">
                                        <img src="<?php echo e(asset('img/resources/man-1.png')); ?>" alt="Awesome Image"/>
                                    </div><!-- /.about-img-box -->
                                </div><!-- /.col-md-5 -->
                            </div><!-- /.row -->
                        </div><!-- /.tab-pane fade -->
                        <div class="tab-pane fade" id="information">
                            <div class="row">
                                <div class="col-md-7">
                                    <div class="about-tab-text-box">
                                        <div class="qouted-text">
                                            <p>
                                                <span class="qoute-top">“</span>
                                                We provide full and specific solution for every client.
                                                <span class="qoute-bottom">”</span>
                                            </p>
                                        </div><!-- /.qouted-text -->
                                        <br />
                                        <br />
                                        <p>Binary Traders Forum is one of the world's best company in a financial sectors We 100%  providing what our customers expects from us.</p>
                                        <p>The Great denouncings pleasures and praisings pains was born and  will give you a complete seds accounts off the systems and expound the actually  teachings the great seds ut explorers the masterd  teachings great explorer of human happiness.</p>
                                        <img src="<?php echo e(asset('img/texture/sign.png')); ?>" alt="Awesome Image"/>
                                    </div><!-- /.about-tab-text-box -->
                                </div><!-- /.col-md-7 -->
                                <div class="col-md-5">
                                    <div class="about-img-box">
                                        <img src="<?php echo e(asset('img/resources/man-1.png')); ?>" alt="Awesome Image"/>
                                    </div><!-- /.about-img-box -->
                                </div><!-- /.col-md-5 -->
                            </div><!-- /.row -->
                        </div><!-- /.tab-pane fade -->
                    </div><!-- /.tab-content -->
                </div><!-- /.col-md-9 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </section><!-- /.sec-pad -->

    <section class="sec-pad-70 pb0 latest-project base-color-bg">
        <div class="container-fulid ">
            <div class="sec-title text-center white">
                <h2>Our Latest Projects</h2>
                <span class="decor-line">
                <span class="decor-line-inner"></span>
            </span>
            </div><!-- /.sec-title -->
            <div class="latest-project-carousel owl-carousel owl-theme">
                <div class="item">
                    <div class="single-latest-project-carousel">
                        <div class="img-box">
                            <img src="<?php echo e(asset('img/project/project-h-1.jpg')); ?>" alt="Awesome Image"/>
                            <div class="overlay">
                                <div class="box">
                                    <div class="content">
                                        <div class="top">
                                            <a data-group="1" href="<?php echo e(asset('img/project/project-h-1.jpg')); ?>" class="img-popup"><i class="fn-icon-magnifier"></i></a>
                                        </div><!-- /.top -->
                                        <div class="bottom clearfix">
                                            <div class="title pull-left">
                                                <h3>Commodities</h3>
                                                <span>Services, Trading</span>
                                            </div><!-- /.title -->
                                            <div class="link-box pull-right">
                                                <a href=""><i class="fn-icon-link"></i></a>
                                            </div><!-- /.link-box -->
                                        </div><!-- /.bottom -->
                                    </div><!-- /.content -->
                                </div><!-- /.box -->
                            </div><!-- /.overlay -->
                        </div><!-- /.img-box -->
                    </div><!-- /.single-latest-project-carousel -->
                </div><!-- /.item -->

                <div class="item">
                    <div class="single-latest-project-carousel">
                        <div class="img-box">
                            <img src="<?php echo e(asset('img/project/project-h-2.jpg')); ?>" alt="Awesome Image"/>
                            <div class="overlay">
                                <div class="box">
                                    <div class="content">
                                        <div class="top">
                                            <a data-group="1" href="<?php echo e(asset('img/project/project-h-2.jpg')); ?>" class="img-popup"><i class="fn-icon-magnifier"></i></a>
                                        </div><!-- /.top -->
                                        <div class="bottom clearfix">
                                            <div class="title pull-left">
                                                <h3>Commodities</h3>
                                                <span>Services, Trading</span>
                                            </div><!-- /.title -->
                                            <div class="link-box pull-right">
                                                <a href=""><i class="fn-icon-link"></i></a>
                                            </div><!-- /.link-box -->
                                        </div><!-- /.bottom -->
                                    </div><!-- /.content -->
                                </div><!-- /.box -->
                            </div><!-- /.overlay -->
                        </div><!-- /.img-box -->
                    </div><!-- /.single-latest-project-carousel -->
                </div><!-- /.item -->

                <div class="item">
                    <div class="single-latest-project-carousel">
                        <div class="img-box">
                            <img src="<?php echo e(asset('img/project/project-h-3.jpg')); ?>" alt="Awesome Image"/>
                            <div class="overlay">
                                <div class="box">
                                    <div class="content">
                                        <div class="top">
                                            <a data-group="1" href="<?php echo e(asset('img/project/project-h-3.jpg')); ?>" class="img-popup"><i class="fn-icon-magnifier"></i></a>
                                        </div><!-- /.top -->
                                        <div class="bottom clearfix">
                                            <div class="title pull-left">
                                                <h3>Commodities</h3>
                                                <span>Services, Trading</span>
                                            </div><!-- /.title -->
                                            <div class="link-box pull-right">
                                                <a href=""><i class="fn-icon-link"></i></a>
                                            </div><!-- /.link-box -->
                                        </div><!-- /.bottom -->
                                    </div><!-- /.content -->
                                </div><!-- /.box -->
                            </div><!-- /.overlay -->
                        </div><!-- /.img-box -->
                    </div><!-- /.single-latest-project-carousel -->
                </div><!-- /.item -->

                <div class="item">
                    <div class="single-latest-project-carousel">
                        <div class="img-box">
                            <img src="<?php echo e(asset('img/project/project-h-4.jpg')); ?>" alt="Awesome Image"/>
                            <div class="overlay">
                                <div class="box">
                                    <div class="content">
                                        <div class="top">
                                            <a data-group="1" href="<?php echo e(asset('img/project/project-h-4.jpg')); ?>" class="img-popup"><i class="fn-icon-magnifier"></i></a>
                                        </div><!-- /.top -->
                                        <div class="bottom clearfix">
                                            <div class="title pull-left">
                                                <h3>Commodities</h3>
                                                <span>Services, Trading</span>
                                            </div><!-- /.title -->
                                            <div class="link-box pull-right">
                                                <a href=""><i class="fn-icon-link"></i></a>
                                            </div><!-- /.link-box -->
                                        </div><!-- /.bottom -->
                                    </div><!-- /.content -->
                                </div><!-- /.box -->
                            </div><!-- /.overlay -->
                        </div><!-- /.img-box -->
                    </div><!-- /.single-latest-project-carousel -->
                </div><!-- /.item -->

                <div class="item">
                    <div class="single-latest-project-carousel">
                        <div class="img-box">
                            <img src="<?php echo e(asset('img/project/project-h-5.jpg')); ?>" alt="Awesome Image"/>
                            <div class="overlay">
                                <div class="box">
                                    <div class="content">
                                        <div class="top">
                                            <a data-group="1" href="<?php echo e(asset('img/project/project-h-5.jpg')); ?>" class="img-popup"><i class="fn-icon-magnifier"></i></a>
                                        </div><!-- /.top -->
                                        <div class="bottom clearfix">
                                            <div class="title pull-left">
                                                <h3>Commodities</h3>
                                                <span>Services, Trading</span>
                                            </div><!-- /.title -->
                                            <div class="link-box pull-right">
                                                <a href=""><i class="fn-icon-link"></i></a>
                                            </div><!-- /.link-box -->
                                        </div><!-- /.bottom -->
                                    </div><!-- /.content -->
                                </div><!-- /.box -->
                            </div><!-- /.overlay -->
                        </div><!-- /.img-box -->
                    </div><!-- /.single-latest-project-carousel -->
                </div><!-- /.item -->
            </div><!-- /.latest-project-carousel -->
        </div><!-- /.container -->
    </section><!-- /.sec-pad -->

    <section class="project-cta">
        <div class="container">
            <div class="left-text pull-left">
                <h3>Did you want to grow your investment plan? Sign up on our platform.</h3>
            </div><!-- /.left-text -->
            <div class="right-button pull-right">
                <a href="<?php echo e(route('register')); ?>" class="thm-btn">Sign up</a>
            </div><!-- /.right-button pull-right -->
        </div><!-- /.container -->
    </section><!-- /.project-cta -->

    <section class=" client-skill-sec has-dot-pattern">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-12">
                    <div class="client-box-wrapper sec-pad pb0">
                        <div class="title">
                            <h2>Our Best Partners & Clients</h2>
                            <p>We provide best services to our customers.</p>
                        </div><!-- /.title -->
                        <div class="client-box">
                            <ul class="list-inline">
                                <li>
                                    <img src="<?php echo e(asset('img/client/client-1.png')); ?>" alt="Awesome Image"/>
                                </li><!-- must add it for inline block hack
                            --><li>
                                    <img src="<?php echo e(asset('img/client/client-2.png')); ?>" alt="Awesome Image"/>
                                </li><!-- must add it for inline block hack
                            --><li>
                                    <img src="<?php echo e(asset('img/client/client-3.png')); ?>" alt="Awesome Image"/>
                                </li><!-- must add it for inline block hack
                            --><li>
                                    <img src="<?php echo e(asset('img/client/client-4.png')); ?>" alt="Awesome Image"/>
                                </li><!-- must add it for inline block hack
                            --><li>
                                    <img src="<?php echo e(asset('img/client/client-5.png')); ?>" alt="Awesome Image"/>
                                </li><!-- must add it for inline block hack
                            --><li>
                                    <img src="<?php echo e(asset('img/client/client-6.png')); ?>" alt="Awesome Image"/>
                                </li>
                            </ul>
                        </div><!-- /.client-box -->
                    </div><!-- /.client-box-wrapper -->
                </div><!-- /.col-md-6 -->
                <div class="col-md-6 col-sm-12">
                    <div class="pgrs-bar-wrapper">
                        <div class="inner-box sec-pad">
                            <div class="title">
                                <h2>Market Overview</h2>
                            </div><!-- /.title -->

                            <!-- TradingView Widget BEGIN -->
                            <div class="tradingview-widget-container">
                                <div class="tradingview-widget-container__widget"></div>
                                <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com" rel="noopener" target="_blank"><span class="blue-text">Market Data</span></a> by TradingView</div>
                                <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-market-overview.js" async>
                                    {
                                        "colorTheme": "light",
                                        "dateRange": "12m",
                                        "showChart": true,
                                        "locale": "en",
                                        "largeChartUrl": "",
                                        "isTransparent": false,
                                        "width": "400",
                                        "height": "450",
                                        "plotLineColorGrowing": "rgba(33, 150, 243, 1)",
                                        "plotLineColorFalling": "rgba(33, 150, 243, 1)",
                                        "gridLineColor": "rgba(240, 243, 250, 1)",
                                        "scaleFontColor": "rgba(120, 123, 134, 1)",
                                        "belowLineFillColorGrowing": "rgba(33, 150, 243, 0.12)",
                                        "belowLineFillColorFalling": "rgba(33, 150, 243, 0.12)",
                                        "symbolActiveColor": "rgba(33, 150, 243, 0.12)",
                                        "tabs": [
                                        {
                                            "title": "Indices",
                                            "symbols": [
                                                {
                                                    "s": "FOREXCOM:SPXUSD",
                                                    "d": "S&P 500"
                                                },
                                                {
                                                    "s": "FOREXCOM:NSXUSD",
                                                    "d": "Nasdaq 100"
                                                },
                                                {
                                                    "s": "FOREXCOM:DJI",
                                                    "d": "Dow 30"
                                                },
                                                {
                                                    "s": "INDEX:NKY",
                                                    "d": "Nikkei 225"
                                                },
                                                {
                                                    "s": "INDEX:DEU30",
                                                    "d": "DAX Index"
                                                },
                                                {
                                                    "s": "FOREXCOM:UKXGBP",
                                                    "d": "FTSE 100"
                                                }
                                            ],
                                            "originalTitle": "Indices"
                                        },
                                        {
                                            "title": "Commodities",
                                            "symbols": [
                                                {
                                                    "s": "CME_MINI:ES1!",
                                                    "d": "E-Mini S&P"
                                                },
                                                {
                                                    "s": "CME:6E1!",
                                                    "d": "Euro"
                                                },
                                                {
                                                    "s": "COMEX:GC1!",
                                                    "d": "Gold"
                                                },
                                                {
                                                    "s": "NYMEX:CL1!",
                                                    "d": "Crude Oil"
                                                },
                                                {
                                                    "s": "NYMEX:NG1!",
                                                    "d": "Natural Gas"
                                                },
                                                {
                                                    "s": "CBOT:ZC1!",
                                                    "d": "Corn"
                                                }
                                            ],
                                            "originalTitle": "Commodities"
                                        },
                                        {
                                            "title": "Bonds",
                                            "symbols": [
                                                {
                                                    "s": "CME:GE1!",
                                                    "d": "Eurodollar"
                                                },
                                                {
                                                    "s": "CBOT:ZB1!",
                                                    "d": "T-Bond"
                                                },
                                                {
                                                    "s": "CBOT:UB1!",
                                                    "d": "Ultra T-Bond"
                                                },
                                                {
                                                    "s": "EUREX:FGBL1!",
                                                    "d": "Euro Bund"
                                                },
                                                {
                                                    "s": "EUREX:FBTP1!",
                                                    "d": "Euro BTP"
                                                },
                                                {
                                                    "s": "EUREX:FGBM1!",
                                                    "d": "Euro BOBL"
                                                }
                                            ],
                                            "originalTitle": "Bonds"
                                        },
                                        {
                                            "title": "Forex",
                                            "symbols": [
                                                {
                                                    "s": "FX:EURUSD"
                                                },
                                                {
                                                    "s": "FX:GBPUSD"
                                                },
                                                {
                                                    "s": "FX:USDJPY"
                                                },
                                                {
                                                    "s": "FX:USDCHF"
                                                },
                                                {
                                                    "s": "FX:AUDUSD"
                                                },
                                                {
                                                    "s": "FX:USDCAD"
                                                }
                                            ],
                                            "originalTitle": "Forex"
                                        }
                                    ]
                                    }
                                </script>
                            </div>
                            <!-- TradingView Widget END -->

                        </div><!-- /.inner-box -->
                    </div><!-- /.pgrs-bar -->
                </div><!-- /.col-md-6 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </section><!-- /.sec-pad client-skill-sec -->

    <section class="sec-pad fact-req-qoute-sec">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="fact-box">
                        <div class="sec-title">
                            <h2>Some Interesting Facts</h2>
                            <span class="decor-line">
                            <span class="decor-line-inner"></span>
                        </span>
                        </div><!-- /.sec-title -->
                        <p>Over the years, we have developed a reputation for integrity, quality and excellence in portfolio management. we are dedicated to offering unparalleled portfolio management services to a wide range of investors worldwide<br>
                            Our services make use of the best pricing, execution and liquidity channels in the global financial market; which is pivotal in the fast paced world of finance and investment. </p>
                        <div class="row fact-row">
                            <div class="col-sm-6">
                                <div class="single-fact-count">
                                    <div class="title clearfix">
                                        <i class="fn-icon-profile"></i>
                                        <span>
                                        <b class="counter">1500</b>+
                                    </span>
                                    </div><!-- /.title -->
                                    <p>Experienced Advisors</p>
                                </div><!-- /.single-fact-count -->
                            </div><!-- /.col-md-6 -->
                            <div class="col-sm-6">
                                <div class="single-fact-count">
                                    <div class="title clearfix">
                                        <i class="fn-icon-location"></i>
                                        <span>0<b class="counter">240</b>+</span>
                                    </div><!-- /.title -->
                                    <p>Worldwide Locations</p>
                                </div><!-- /.single-fact-count -->
                            </div><!-- /.col-md-6 -->
                            <div class="col-sm-6">
                                <div class="single-fact-count">
                                    <div class="title clearfix">
                                        <i class="fn-icon-graphic"></i>
                                        <span>00<b class="counter">34</b></span>
                                    </div><!-- /.title -->
                                    <p>Years of Experience</p>
                                </div><!-- /.single-fact-count -->
                            </div><!-- /.col-md-6 -->
                            <div class="col-sm-6">
                                <div class="single-fact-count">
                                    <div class="title clearfix">
                                        <i class="pull-left fn-icon-people"></i>
                                        <span>
                                        <b class="counter">3457</b>+
                                    </span>
                                    </div><!-- /.title -->
                                    <p>Satisfied Customers</p>
                                </div><!-- /.single-fact-count -->
                            </div><!-- /.col-md-6 -->
                        </div><!-- /.row -->
                    </div><!-- /.fact-box -->
                </div><!-- /.col-md-6 -->
                <div class="col-md-6">
                    <div class="rqa-box">
                        <div class="sec-title">
                            <h2>Request a Free Consultation</h2>
                            <span class="decor-line">
                            <span class="decor-line-inner"></span>
                        </span>
                        </div><!-- /.sec-title -->
                        <form action="" class="contact-form">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-grp">
                                        <label>Your Name*</label>
                                        <input type="text" name="name" placeholder="Your Name *" />
                                    </div><!-- /.form-grp -->
                                </div><!-- /.col-md-6 -->
                                <div class="col-md-6">
                                    <div class="form-grp">
                                        <label>Email Address*</label>
                                        <input type="text" name="email" placeholder="Email Address *" />
                                    </div><!-- /.form-grp -->
                                </div><!-- /.col-md-6 -->
                                <div class="col-md-6">
                                    <div class="form-grp">
                                        <label>Contact Num</label>
                                        <input type="text" name="phone" placeholder="Phone" />
                                    </div><!-- /.form-grp -->
                                </div><!-- /.col-md-6 -->
                                <div class="col-md-6">
                                    <div class="form-grp">
                                        <label>Discuss About*</label>
                                        <div class="select-box">
                                            <select class="selectpicker" name="services">
                                                <option value="">Select Service</option>
                                                <option value="1">Mutual Funds</option>
                                                <option value="2">Investment Planning</option>
                                                <option value="3">Personal Insurance</option>
                                                <option value="4">Industrial Insurance</option>
                                                <option value="5">Commodities Trading</option>
                                                <option value="6">Retirement Planning</option>
                                                <option value="7">Wealth Management</option>
                                                <option value="8">Audit & Tax Planning</option>
                                            </select>
                                        </div><!-- /.select-box -->
                                    </div><!-- /.form-grp -->
                                </div><!-- /.col-md-6 -->
                                <div class="col-md-12">
                                    <div class="form-grp">
                                        <textarea name="message" placeholder="Special Request..."></textarea>
                                    </div><!-- /.form-grp -->
                                    <button type="submit" class="thm-btn">Submit Now</button>

                                    <div class="form-result"></div><!-- /.form-result -->
                                </div><!-- /.col-md-6 -->
                            </div><!-- /.row -->
                        </form>

                    </div><!-- /.rqa-box -->
                </div><!-- /.col-md-6 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </section><!-- /.sec-pad -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\digital_metrics_invest\resources\views/home.blade.php ENDPATH**/ ?>
