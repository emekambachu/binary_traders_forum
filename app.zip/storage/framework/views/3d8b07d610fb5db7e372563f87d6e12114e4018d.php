<?php if(session('success')): ?>
    <div style="width: 50%; margin: 10px auto; color: #0b0b0b;" align="center" class="alert alert-success" role="alert">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

<?php if(session('warning')): ?>
    <div style="width: 50%; margin: 10px auto;" align="center" class="alert alert-danger" role="alert">
        <?php echo e(session('warning')); ?>

    </div>
<?php endif; ?>

<?php if(count($errors) > 0): ?>
    <div style="width: 50%; margin: 10px auto;" align="center" class="alert alert-danger" role="alert">
        <ul style="list-style: none;">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\binary_traders_forum\resources\views/includes/alerts.blade.php ENDPATH**/ ?>