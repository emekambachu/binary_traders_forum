<?php $__env->startSection('title'); ?>
    Investment Packages
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
    <div id="content-page" class="content-page">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">

                    <div class="iq-card">
                        <div class="iq-card-header d-flex justify-content-between">
                            <div class="iq-header-title" style="display: inline-block;">
                                <h4 style="float: left;" class="card-title mr-2">Manage Investments</h4>
                                <a style="float: left;" href="<?php echo e(route('investment-packages.create')); ?>">
                                    <button class="btn btn-sm btn-info">Add Investment Package</button>
                                </a>
                            </div>
                            <?php echo $__env->make('includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="iq-card-body">
                            <p>Manage Investment Packages</p>
                            <div class="table-responsive">
                                <?php if($packages->count() > 0): ?>
                                    <table id="datatable" class="table table-striped table-bordered">
                                        <thead>
                                        <tr>
                                            <th scope="col">Name</th>
                                            <th scope="col">Range</th>
                                            <th scope="col">Referral Bonus</th>
                                            <th scope="col">Monthly Profit</th>
                                            <th scope="col">Days Turnover</th>
                                            <th scope="col">Expert Advice</th>
                                            <th scope="col">Deposit Bonus</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($package->name); ?></td>
                                                <td>$<?php echo e($package->min); ?> to $<?php echo e($package->min); ?></td>
                                                <td>%<?php echo e($package->referral_bonus); ?></td>
                                                <td>%<?php echo e($package->monthly_profit); ?></td>
                                                <td><?php echo e($package->days_turnover); ?></td>
                                                <td><?php echo e($package->expert_advice); ?></td>
                                                <td>%<?php echo e($package->deposit_bonus); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('investment-packages.edit', $package->id)); ?>">
                                                        <button class="btn btn-info btn-sm"><i class="fa fa-pencil"></i> Edit</button>
                                                    </a>
                                                    <form method="POST" action="<?php echo e(route('investment-packages.destroy', $package->id)); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="_method" value="DELETE">
                                                        <button class="btn btn-sm btn-danger" type="submit">
                                                            <i class="fa fa-trash"></i> Delete
                                                        </button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        <tfoot>
                                        <tr>
                                            <th scope="col">Name</th>
                                            <th scope="col">Range</th>
                                            <th scope="col">Referral Bonus</th>
                                            <th scope="col">Monthly Profit</th>
                                            <th scope="col">Days Turnover</th>
                                            <th scope="col">Expert Advice</th>
                                            <th scope="col">Deposit Bonus</th>
                                        </tr>
                                        </tfoot>
                                    </table>
                                <?php else: ?>
                                    No Current Investments
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\digital_metrics_invest\resources\views/admin/investment-packages/index.blade.php ENDPATH**/ ?>