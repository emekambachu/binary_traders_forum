<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title'); ?> - Digital Metrics investment</title>

    <!-- mobile responsive meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/responsive.css')); ?>">

    <?php echo $__env->yieldContent('top-assets'); ?>
</head>
<body>

<header class="header header-fixed header-2">

    <nav class="navbar navbar-default header-navigation stricky">
        <div class="header-top">
            <div class="container">
                <div class="left-info pull-left">
                    <ul class="list-inline">
                        <li>
                            <div class="dropdown">
                                <div id="google_translate_element"></div>
                            </div>
                        </li>
                    </ul>
                </div><!-- /.left-info -->

                <div class="right-info pull-right">
                    <ul class="list-inline">
                        <li><span><i class="fa fa-envelope"></i> info@binarytradersforum.com</span></li>
                    </ul>
                </div><!-- /.right-info -->

            </div>
        </div><!-- /.header-top -->

        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#main-nav-bar" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(asset('binary_traders_forum_logo.png')); ?>" alt="Binary Traders Forum"/>
                </a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="main-nav-bar">
                <ul class="nav navbar-nav navigation-box">
                    <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li><a href="<?php echo e(url('investment')); ?>">Investment</a></li>
                    <li><a href="<?php echo e(url('about')); ?>">About us</a></li>
                    <li><a href="<?php echo e(url('services')); ?>">Services</a></li>
                    <li><a href="<?php echo e(url('contact')); ?>">Contact</a></li>
                    <li style="background-color: #78b822; color: #fff; padding-top: 4px; padding-bottom: 4px; border-radius: 4px;">
                        <a href="<?php echo e(route('register')); ?>">Sign up</a></li>
                    <li style="background-color: #78b822; color: #fff; padding-top: 4px; padding-bottom: 4px; border-radius: 4px;">
                        <a href="<?php echo e(route('login')); ?>">Login</a></li>
                </ul>
            </div><!-- /.navbar-collapse -->

        </div><!-- /.container -->
    </nav>
</header><!-- /.header -->

<?php echo $__env->yieldContent('contents'); ?>

<footer class="footer has-dot-pattern sec-pad">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="single-footer-widget about-widget">
                    <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('binary_traders_forum_logo.png')); ?>" alt="Binary Traders Forum"/></a>
                    <ul class="contact-info">
                        <li>
                            <div class="icon-box">
                                <i class="fa fa-map-marker"></i>
                            </div><!-- /.icon-box -->
                            <div class="text-box">
                                <p>Address: 555 west 5th street, 35th Floor, Los Angeles, California</p>
                            </div><!-- /.text-box -->
                        </li>
                        <li>
                            <div class="icon-box">
                                <i class="fa fa-envelope-o"></i>
                            </div><!-- /.icon-box -->
                            <div class="text-box">
                                <p>info@binarytradersforum.com</p>
                            </div><!-- /.text-box -->
                        </li>
                    </ul>
                </div><!-- /.single-footer-widget -->
            </div><!-- /.col-md-3 -->

            <div class="col-lg-3 col-md-6">
                <div class="single-footer-widget link-widget">
                    <div class="sec-title white medium">
                        <h2>Quick Links</h2>
                        <span class="decor-line">
								<span class="decor-line-inner"></span>
							</span>
                    </div><!-- /.sec-title -->
                    <div class="clearfix">
                        <div class="col-md-12">
                            <ul class="links">
                                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                                <li><a href="<?php echo e(url('about')); ?>">About Us</a></li>
                                <li><a href="<?php echo e(url('services')); ?>">Services</a></li>
                                <li><a href="<?php echo e(url('contact')); ?>">Contact</a></li>
                                <li><a href="<?php echo e(route('register')); ?>">Sign up</a></li>
                                <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                            </ul><!-- /.links -->
                        </div><!-- /.col-md-6 -->
                    </div><!-- /.row -->
                </div><!-- /.single-footer-widget -->
            </div><!-- /.col-md-3 -->

            <div class="col-lg-3 col-md-6">
                <div class="single-footer-widget latest-news">
                    <div class="sec-title white medium">
                        <h2>Latest News</h2>
                        <span class="decor-line">
								<span class="decor-line-inner"></span>
							</span>
                    </div><!-- /.sec-title -->
                    <ul class="latest-post">
                        <li>
                            <div class="icon-box">
                                <img src="<?php echo e(asset('img/resources/footer-latest-1.jpg')); ?>" alt="Awesome Image"/>
                            </div><!-- /.icon-box -->
                            <div class="text-box">
                                <a href="#"><h4>Seminar for improve your<br />all business growth. </h4></a>
                                <a href="#"><p>August 21, 2014</p></a>
                            </div><!-- /.text-box -->
                        </li>
                        <li>
                            <div class="icon-box">
                                <img src="<?php echo e(asset('img/resources/footer-latest-2.jpg')); ?>" alt="Awesome Image"/>
                            </div><!-- /.icon-box -->
                            <div class="text-box">
                                <a href="#"><h4>Banking & financial crises<br />of Binary Traders Forum.</h4></a>
                                <a href="#"><p>December 17, 2015</p></a>
                            </div><!-- /.text-box -->
                        </li>
                        <li>
                            <div class="icon-box">
                                <img src="<?php echo e(asset('img/resources/footer-latest-3.jpg')); ?>" alt="Awesome Image"/>
                            </div><!-- /.icon-box -->
                            <div class="text-box">
                                <a href="#"><h4>We provide full & specific<br />solution for you.</h4></a>
                                <a href="#"><p>January 11, 2015</p></a>
                            </div><!-- /.text-box -->
                        </li>
                    </ul><!-- /.latest-post -->
                </div><!-- /.single-footer-widget -->
            </div><!-- /.col-md-3 -->

            <div class="col-lg-3 col-md-6">
                <div class="single-footer-widget subscribe">
                    <div class="sec-title white medium">
                        <h2>Subscribe Us</h2>
                        <span class="decor-line">
								<span class="decor-line-inner"></span>
							</span>
                    </div><!-- /.sec-title -->
                    <form action="" class="clearfix mailchimp-form">
                        <input type="text" name="email" placeholder="Email address" />
                        <button type="submit">go</button>
                    </form>
                    <p>Get Latest Updates & Offer</p>
                    <div class="result"></div><!-- /.result -->
                </div><!-- /.single-footer-widget -->
            </div><!-- /.col-md-3 -->

        </div><!-- /.row -->
    </div><!-- /.container -->
</footer><!-- /.footer -->

<section class="footer-bottom">
    <div class="container">
        <div class="copyright pull-left">
            <p>Copyrights © <?php echo e(date('Y')); ?> All Rights Binary Traders Forum.</p>
        </div><!-- /.copyright pull-left -->
        <div class="social pull-right">
            <ul class="list-inline">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
            </ul><!-- /.list-inline -->
        </div><!-- /.social pull-right -->
    </div><!-- /.container -->
</section><!-- /.footer-bottom -->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-up"></span></div>

<script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('assets/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>"></script>

<!-- revolution slider js -->
<script src="<?php echo e(asset('assets/revolution/js/jquery.themepunch.tools.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/revolution/js/jquery.themepunch.revolution.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.actions.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.kenburn.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.layeranimation.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.migration.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.navigation.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.parallax.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.slideanims.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.video.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/gmaps.js')); ?>"></script>
<!-- google map helper -->
<script src="<?php echo e(asset('assets/map-helper.js')); ?>"></script>

<script src="<?php echo e(asset('assets/jquery-validation/dist/jquery.validate.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/owl.carousel-2/owl.carousel.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/nouislider/nouislider.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bootstrap-touch-spin/jquery.bootstrap-touchspin.js')); ?>"></script>

<script src="<?php echo e(asset('assets/isotope.js')); ?>"></script>

<script src="<?php echo e(asset('assets/masterslider/masterslider.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/bxslider/dist/jquery.bxslider.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/chartjs/dist/Chart.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/jquery-circle-progress-1.1.2/dist/circle-progress.js')); ?>"></script>
<script src="<?php echo e(asset('assets/morris.js-master/morris.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/raphael-master/raphael.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/Magnific-Popup-master/dist/jquery.magnific-popup.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/jquery.counterup.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/wow.min.js')); ?>"></script>

<script src="<?php echo e(asset('js/custom.js')); ?>"></script>

<?php echo $__env->yieldContent('bottom-assets'); ?>

<script type="text/javascript">
    function googleTranslateElementInit() {
        new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
    }
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

<!--Start of Tawk.to Script-->
<script type="text/javascript">
    var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
    (function(){
        var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
        s1.async=true;
        s1.src='https://embed.tawk.to/5ed3b23d8ee2956d73a63a0f/default';
        s1.charset='UTF-8';
        s1.setAttribute('crossorigin','*');
        s0.parentNode.insertBefore(s1,s0);
    })();
</script>
<!--End of Tawk.to Script-->

</body>

</html>
<?php /**PATH C:\wamp64\www\digital_metrics_invest\resources\views/layouts/main.blade.php ENDPATH**/ ?>
