<img src="<?php echo e(asset('binary_traders_forum_logo.png')); ?>" width="100">

<h3>Hello <?php echo e($name); ?>,</h3>

<h4>A credit transaction was made to your account.</h4><br>

<strong>Transaction Details</strong><br>
<p><strong>Description:</strong> <?php echo e($description); ?></p>
<p><strong>Amount:</strong> $<?php echo e($amount); ?></p>
<p><strong>Date of Transaction:</strong> <?php echo e($time); ?></p>
<p><strong>Transaction Reference Number:</strong> <?php echo e($ref); ?></p>

<strong>Your Wallet Balance as at <?php echo e($time); ?></strong><br>
<p><strong>Current Balance:</strong> $<?php echo e(number_format($balance)); ?></p>";
<?php /**PATH C:\wamp64\www\digital_metrics_invest\resources\views/emails/fund-wallet.blade.php ENDPATH**/ ?>
