<?php $__env->startSection('title'); ?>
    Add New Investment
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
    <div id="content-page" class="content-page">
        <div class="container-fluid">

            <div class="row">
                <div class="col-sm-12 col-lg-6">
                    <div class="iq-card">
                        <div class="iq-card-header d-flex justify-content-between">
                            <div class="iq-header-title">
                                <h4 class="card-title"> Make payment using the bitcoin address below</h4>
                            </div>
                        </div>
                        <div class="iq-card-body" style="margin: 0 auto;">
                            <p><strong>1BxLSTsk4mgvspTmC3YPdEJts2JRJ9YzTL</strong></p>
                            <div class="card iq-mb-2">
                                <img width="300" src="<?php echo e(asset('bitcoin_scan.jpeg')); ?>">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-sm-12 col-lg-6">
                    <div class="iq-card">
                        <div class="iq-card-header d-flex justify-content-between">
                            <div class="iq-header-title">
                                <h4 class="card-title"> Add New Investment</h4>
                            </div>
                        </div>
                        <?php echo $__env->make('includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="iq-card-body">
                            <p><strong>After making your payment, submit you bitcoin payment details.</strong></p>
                            <form method="post" action="<?php echo e(url('user/submit-investment')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-row">
                                    <div class="col-md-6 mb-3">
                                        <label for="validationDefault01">Amount</label>
                                        <input name="amount" type="number" class="form-control" id="validationDefault01" required="">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="validationDefault02">Package</label>
                                        <select name="package" class="form-control" required>
                                            <option disabled>Select Investment Plan</option>
                                            <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pack): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($pack->id); ?>"><?php echo e($pack->name); ?> $<?php echo e(number_format($pack->min)); ?> - $<?php echo e(number_format($pack->max)); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button class="btn brand-color" type="submit">Continue</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.users', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\digital_metrics_invest\resources\views/users/investments/create.blade.php ENDPATH**/ ?>