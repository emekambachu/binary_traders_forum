<?php $__env->startSection('title'); ?>
    Manage Users
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
    <div id="content-page" class="content-page">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">

                    <div class="iq-card">
                        <div class="iq-card-header d-flex justify-content-between">
                            <div class="iq-header-title" style="display: inline-block;">
                                <h4 style="float: left;" class="card-title mr-2">Manage Users</h4>
                            </div>
                            <?php echo $__env->make('includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="iq-card-body">
                            <p>Manage users and User Wallet</p>
                            <div class="table-responsive">
                                <?php if($users->count() > 0): ?>
                                    <table id="datatable" class="table table-striped table-bordered">
                                        <thead>
                                        <tr>
                                            <th scope="col">Name</th>
                                            <th scope="col">Email</th>
                                            <th scope="col">Country</th>
                                            <th scope="col">Wallet</th>
                                            <th scope="col">Date</th>
                                            <th scope="col">Status</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($user->name); ?></td>
                                                <td><?php echo e($user->email); ?></td>
                                                <td><?php echo e($user->country); ?></td>
                                                <td>$<?php echo e($user->wallet->amount); ?></td>
                                                <td><?php echo e($user->created_at->format('d M Y')); ?></td>
                                                <td><?php echo e($user->is_active ? 'Active' : 'Blocked'); ?></td>
                                                <td>
                                                    <a href="<?php echo e(url('admin/fund-wallet/'.$user->id)); ?>">
                                                        <button class="btn btn-info btn-sm">Fund Wallet</button>
                                                    </a>

                                                    <form method="POST" action="<?php echo e(action('AdminController@approveUser', $user->id)); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="btn btn-warning btn-sm">
                                                            <?php echo e($user->is_active ? 'Block User' : 'Unblock User'); ?>

                                                        </button>
                                                    </form>

                                                    <form method="POST" action="<?php echo e(action('AdminController@deleteUser', $user->id)); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="btn btn-dark btn-sm">
                                                            Delete
                                                        </button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        <tfoot>
                                        <tr>
                                            <th scope="col">Name</th>
                                            <th scope="col">Email</th>
                                            <th scope="col">Country</th>
                                            <th scope="col">Wallet</th>
                                            <th scope="col">Date</th>
                                            <th scope="col">Status</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                        </tfoot>
                                    </table>
                                <?php else: ?>
                                    No Current User
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\digital_metrics_invest\resources\views/admin/manage-users.blade.php ENDPATH**/ ?>