<?php $__env->startSection('title'); ?>
    Fund Wallet
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
    <div id="content-page" class="content-page">
        <div class="container-fluid">

            <div class="row">
                <div class="col-sm-12 col-lg-6" style="margin: 0 auto;">
                    <div class="iq-card">

                        <div class="iq-card-header d-flex justify-content-between">
                            <div class="iq-header-title">
                                <h4 class="card-title">Fund <?php echo e($user->name); ?>'s Wallet</h4>
                                <p><strong>Current Balance:</strong> $<?php echo e($user->wallet->amount); ?></p>
                            </div>
                        </div>

                        <?php echo $__env->make('includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <div class="iq-card-body">
                            <form method="post" action="">
                                <?php echo csrf_field(); ?>
                                <div class="form-row">
                                    <div class="col-md-6 mb-3">
                                        <label for="validationDefault01">Amount</label>
                                        <input name="amount" type="number" class="form-control" id="validationDefault01" required="">
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="col-md-6 mb-3">
                                        <label for="validationDefault01">Description</label>
                                        <textarea class="form-control" name="description" required>
                                        </textarea>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button class="btn brand-color" type="submit">Fund</button>
                                </div>
                            </form>
                        </div>

                    </div>
                </div>
            </div>

        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\digital_metrics_invest\resources\views/admin/fund-wallet.blade.php ENDPATH**/ ?>