<?php $__env->startSection('title'); ?>
    Admin Login
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
    <section class="inner-banner has-dot-pattern">
        <div class="container">
            <h2>Admin Login</h2>
            <span class="decor-line"></span>
            <ul class="list-inline bread-cumb">
                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li><span>Admin Login</span></li>
            </ul><!-- /.list-inline -->
        </div><!-- /.container -->
    </section>

    <section class="sec-pad contact-page">
        <div class="container">
            <div class="col-md-8">
                <form method="POST" action="<?php echo e(route('admin-login')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="row">

                        <div class="col-md-6">
                            <div class="form-grp">
                                <label>Username</label>
                                <input class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="username"
                                       value="<?php echo e(old('username')); ?>" placeholder="Username *" required>
                                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div><!-- /.form-grp -->
                        </div><!-- /.col-md-6 -->

                        <div class="col-md-6">
                            <div class="form-grp">
                                <label>Password</label>
                                <input class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password" name="password"
                                       placeholder="password" required>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div><!-- /.form-grp -->
                        </div><!-- /.col-md-6 -->

                        <div class="col-md-12" style="margin-top: 6px;">
                            <button type="submit" class="btn btn-primary">Login</button>
                        </div><!-- /.col-md-6 -->

                    </div><!-- /.row -->
                    <div class="form-result"></div><!-- /.form-result -->
                </form>
            </div><!-- /.col-md-8 -->

            <div class="col-md-4">
                <div class="contact-info-box">
                    <p>Login to continue your investment.</p>
                    <ul class="info-items">
                        <li>
                            <div class="icon-box">
                                <div class="inner-box">
                                    <i class="fa fa-envelope"></i>
                                </div><!-- /.inner-box -->
                            </div><!-- /.icon-box -->
                            <div class="text-box">
                                <h3>Ask Anything Here :</h3>
                                <p>info@binarytradersforum.com</p>
                            </div><!-- /.text-box -->
                        </li>
                    </ul><!-- /.info-items -->
                </div><!-- /.contact-info-box -->
            </div><!-- /.col-md-8 -->
        </div><!-- /.container -->
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\digital_metrics_invest\resources\views/auth/admin-login.blade.php ENDPATH**/ ?>
