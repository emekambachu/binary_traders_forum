<?php $__env->startSection('title'); ?>
    Investments
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
    <div id="content-page" class="content-page">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">

                    <div class="iq-card">
                        <div class="iq-card-header d-flex justify-content-between">
                            <div class="iq-header-title" style="display: inline-block;">
                                <h4 style="float: left;" class="card-title mr-2">Your Investments</h4>
                                <a href="<?php echo e(route('investment.create')); ?>">
                                    <button style="float: left;" class="btn btn-sm brand-color">Add New Investment</button>
                                </a>
                            </div>
                            <?php echo $__env->make('includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="iq-card-body">
                            <p>Your current investments are displayed here</p>
                            <div class="table-responsive">
                                <?php if($investments->count() > 0): ?>
                                <table id="datatable" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th scope="col">Investment ID</th>
                                            <th scope="col">Package</th>
                                            <th scope="col">Amount</th>
                                            <th scope="col">Date</th>
                                            <th scope="col">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $investments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($invest->invest_id); ?></td>
                                                <td><?php echo e($invest->investmentPackage ? $invest->investmentPackage->name : ''); ?></td>
                                                <td>$<?php echo e(number_format($invest->amount)); ?></td>
                                                <td><?php echo e($invest->created_at->format('d M Y')); ?></td>
                                                <td><?php echo e($invest->is_approved ? 'Approved' : 'Unapproved'); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th scope="col">Investment ID</th>
                                            <th scope="col">Package</th>
                                            <th scope="col">Amount</th>
                                            <th scope="col">Date</th>
                                            <th scope="col">Status</th>
                                        </tr>
                                    </tfoot>
                                </table>
                                <?php else: ?>
                                    You have no current investments
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.users', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\binary_traders_forum\resources\views/users/investments/index.blade.php ENDPATH**/ ?>