
<img src="{{ asset('binary_traders_forum_logo.png') }}" width="100">

<h3>Dear {{ $name }},</h3>

<p>
    Thank you for registering to join our investment platform.<br>
    This is a great journey to financial freedom.<br><br>
</p>

<p>We look forward to seeing you on the platform.<br><br>

<p align="center">Need more information?<br>
    Please contact <strong>info@binarytradersforum.com</strong>.</p>


