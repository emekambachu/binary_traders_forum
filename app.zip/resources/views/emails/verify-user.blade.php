
<img src="{{ asset('binary_traders_forum_logo.png') }}" width="100">

<h3>Hello {{ $name }}</h3>

<p>
    {{ $status }}
</p>

<p align="center">Need more information?<br>
    Please contact <strong>info@binarytradersforum.com</strong>.</p>
